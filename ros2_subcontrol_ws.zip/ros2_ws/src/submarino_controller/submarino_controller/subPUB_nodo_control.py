#!/usr/bin/env python3

import rclpy
from geometry_msgs.msg import Twist
from pynput import keyboard
from rclpy.node import Node

movimiento = [0,0,0]

def set_movimiento(valorx: float,valory: float, valorAngz: float):
        global movimiento
        movimiento = [valorx, valory, valorAngz]

class Publicador(Node):

    def __init__(self):
        super().__init__('publicador')
        self.publisher_ = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        timer_period = 1  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)


    def timer_callback(self):

        msg = Twist()
        

        def press(key):
            if key.char == "a":
                set_movimiento(0.0, 0.5, 0.0)
            if key.char == "d":
                set_movimiento(0.0, -0.5, 0.0)
            if key.char == "s":
                set_movimiento(-0.5, 0.0, 0.0)
            if key.char == "w":
                set_movimiento(0.5, 0.0, 0.0)
            if key.char == "q":
                set_movimiento(0.0, 0.0, 0.5)
            if key.char == "e":
                set_movimiento(0.0, 0.0, -0.5)
            
            msg.linear.x = movimiento[0]
            msg.linear.y = movimiento[1]
            msg.angular.z = movimiento[2]
            print(movimiento)
            self.get_logger().info("str(movimiento)")
            #msg.linear.y = movimiento["y"]
            #msg.angular.z = movimiento["z"]
        
            self.publisher_.publish(msg)

        with keyboard.Listener(
            on_press=press) as listener:
                listener.join()



def main(args=None):
    rclpy.init(args=args)
    node = Publicador()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "_main_":
    main()